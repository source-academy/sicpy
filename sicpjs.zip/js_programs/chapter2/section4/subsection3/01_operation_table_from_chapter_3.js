// operation_table, put and get
// from chapter 3 (section 3.3.3)
