const f_1 = list("A", 4);
const my_frequency_1 = 
    attach_tag("frequency_list", f_1);

type_tag(my_frequency_1);
