head(reverse(list(1, 4, 5, 9, 16, 25)));
