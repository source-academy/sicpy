function divide(x, y) {
    return x / y;
}
