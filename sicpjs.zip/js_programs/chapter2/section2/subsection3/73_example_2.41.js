length(triples_that_sum_to(10, 6));
