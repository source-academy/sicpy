const x = list(list(1, 2), list(3, 4));
// fringe to be written by student
length(fringe(list(x, x)));
