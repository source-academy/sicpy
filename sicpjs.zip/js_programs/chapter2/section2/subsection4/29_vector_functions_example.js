const my_vector_1 = make_vect(1, 2);
const my_vector_2 = make_vect(3, 4);
add_vect(my_vector_1, my_vector_2);
