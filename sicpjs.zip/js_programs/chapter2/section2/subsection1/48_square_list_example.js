tail(square_list(list(1, 2, 3, 4)));
