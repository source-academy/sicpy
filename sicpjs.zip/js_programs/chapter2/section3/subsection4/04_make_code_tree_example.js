const my_leaf_1 = make_leaf("A", 8);
const my_leaf_2 = make_leaf("B", 3);

head(tail(make_code_tree(my_leaf_1, my_leaf_2)));
