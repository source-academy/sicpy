is_same_variable("xyz", "xyz");
