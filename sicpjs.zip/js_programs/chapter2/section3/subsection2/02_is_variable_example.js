is_variable("xyz");
