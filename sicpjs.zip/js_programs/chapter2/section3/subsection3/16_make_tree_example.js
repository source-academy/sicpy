entry(
  left_branch(
    right_branch(
      make_tree(10,
                null,
                make_tree(30,
                          make_tree(20, null, null),
                          null)))));
