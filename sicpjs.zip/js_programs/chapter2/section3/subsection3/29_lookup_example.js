lookup(3, list(make_record(2, "Venus"), 
               make_record(5, "Jupiter"),
               make_record(4, "Mars"),
               make_record(3, "Earth"),
               make_record(6, "Saturn")));
