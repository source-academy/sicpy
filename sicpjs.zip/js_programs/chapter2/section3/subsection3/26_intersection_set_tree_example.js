tree_to_list_2(intersection_set_as_tree(
                   list_to_tree(list(1, 3, 5, 8)),
                   list_to_tree(list(2, 3, 6, 8)) ) );
