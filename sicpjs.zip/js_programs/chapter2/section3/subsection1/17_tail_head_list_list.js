tail(head(list(list("x1", "x2"), list("y1", "y2"))));
// ["x2", null]

// expected: [ 'x2', null ]
