tail(pair(3, 4));
