const one_half = make_rat(1, 2);

one_half;
