const x = pair(1, 2);

const y = pair(3, 4);

const z = pair(x, y);
head(tail(z));

// expected: 3
